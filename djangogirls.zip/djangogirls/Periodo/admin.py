from django.contrib import admin
from .models import Periodo

admin.site.register(Periodo)