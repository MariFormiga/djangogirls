from django.db import models
from django.utils import timezone

class Controle_de_Validade (models.Model):
    Descricao = models.CharField(max_length=200)
    Ordenar = models.CharField(max_length=200)
    Dias = models.CharField(max_length=200)
    Validade = models.CharField(max_length=200)

class Ficha_Cardex (models.Model):
    Produto = models.CharField(max_length=200)
    Periodo = models.CharField(max_length=200)

class Itens (models.Model):
    Descricao = models.CharField(max_length=200)

class Devolucao_de_Produtos (models.Model):
    Pratica = models.CharField(max_length=200)
    Unidade = models.CharField(max_length=200)
    Periodo = models.CharField(max_length=200)

class Livro_de_Registro (models.Model):
    Item = models.CharField(max_length=200)
    Data_de_Inicio = models.CharField(max_length=200)
    Data_Final = models.CharField(max_length=200)
    Unidade = models.CharField(max_length=200)

class Ultimas_Compras (models.Model):
    Item = models.CharField(max_length=200)
    Data_de_Inicio = models.CharField(max_length=200)
    Data_Final = models.CharField(max_length=200)
    Unidade = models.CharField(max_length=200)

class Fornecedor (models.Model):
    Escolher_Letra = models.CharField(max_length=200)


