from django.contrib import admin
from .models import Vidrarias

admin.site.register(Vidrarias)