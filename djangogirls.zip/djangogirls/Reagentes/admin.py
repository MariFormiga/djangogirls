from django.contrib import admin
from .models import Reagente

admin.site.register(Reagente)