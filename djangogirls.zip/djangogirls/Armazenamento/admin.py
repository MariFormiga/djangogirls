from django.contrib import admin
from .models import Armazenamento

admin.site.register(Armazenamento)