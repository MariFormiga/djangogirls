from django.db import models
from django.utils import timezone

class Baixa (models.Model):
    Produto = models.CharField(max_length=200)

