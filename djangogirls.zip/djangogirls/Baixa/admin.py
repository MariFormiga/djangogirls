from django.contrib import admin
from .models import Baixa

admin.site.register(Baixa)
