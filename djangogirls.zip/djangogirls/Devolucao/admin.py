from django.contrib import admin
from .models import Devolucao

admin.site.register(Devolucao)
