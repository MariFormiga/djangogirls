from django.db import models
from django.utils import timezone

class Devolucao (models.Model):
    Produto = models.CharField(max_length=200)
    Quantidade = models.CharField(max_length=200)
    Unidade = models.CharField(max_length=200)